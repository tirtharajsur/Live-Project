package com.cg.project.eis;
@FunctionalInterface
public interface Factorial {
	public long fact(int num);
}
