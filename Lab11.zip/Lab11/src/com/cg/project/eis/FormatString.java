package com.cg.project.eis;
@FunctionalInterface
public interface FormatString {
	public String formatString(String s);
}
