package com.cg.project.eis;

public interface SumOfSalary {
	public double sumSalary();

}
