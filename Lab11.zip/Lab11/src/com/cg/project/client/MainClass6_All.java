package com.cg.project.client;

import com.cg.project.eis.SumOfSalary;
import com.cg.project.util.*;
import com.cg.project.beans.*;
public class MainClass6_All {

	public static void main(String[] args) {
		
		calculateSumOfSalary();

	}
	public static void calculateSumOfSalary() {
		SumOfSalary sum = ()->{
			int i = EmployeeRepository.EMPLOYEE_ID_COUNTER;
			double salary=0;
			for (Employee e : EmployeeRepository.employeeDetails.values()) {
				salary += e.getSalary();
			}
			return salary;
		};
		System.out.println("Sum of salary: "+sum.sumSalary());
	}
	

}
