package com.cg.payroll.client;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		PayrollServices services = new PayrollServicesImpl();
		int associateId= services.acceptAssociateDetails("Tirtharaj", "Sur","tirtharajsur@gmail.com","YTP","Sn Con","JPQO1542AD",15200,30000, 200,1000,10001,"CITI Bank","CITI00002");
		int associateId2 = services.acceptAssociateDetails("Debraj", "Chatterjee","debu.chat@gmail.com","MTP","Jn Con","BCQO1542AD",25200,32000, 300,2000,10002,"CITI Bank","CITI00003");
		System.out.println("Associate ID: "+associateId);
		System.out.println("Associate ID: "+associateId2);
		Associate associate = null;
		try {
			associate = services.getAssociateDetails(associateId); 
			System.out.println("\nDetails found for Associate ID: "+associateId);
			System.out.println("Annual Net Salary: "+services.calculateNetSalary(associateId));
			System.out.println("Monthly Gross Salary: "+services.calculateGrossSalary(associateId));
		}
		catch(AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}	
		try {
			associate = services.getAssociateDetails(associateId2); 
			System.out.println("\nDetails found for Associate ID: "+associateId2);
			System.out.println("Annual Net Salary: "+services.calculateNetSalary(associateId2));
			System.out.println("Monthly Gross Salary: "+services.calculateGrossSalary(associateId2));
			
		}
		catch(AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
	
		/*........................................For an invalid Employee ID.........................................*/
		/* * 
		 * try {
			associate = services.getAssociateDetails(80);
			System.out.println("Details found for Associate ID: "+80);
			System.out.println("Annual Net Salary: "+services.calculateNetSalary(associateId));
		}
		catch(AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		
		List<Associate> a1 = services.getAllAssociateDetails();
		for (Associate associate2 : a1) {
			System.out.println(associate2);
		}
		*/

	}
}
